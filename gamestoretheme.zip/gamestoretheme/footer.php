<footer>
<section class="top-footer row">
    <div class="gamestore-info-widget-area col-sm-12 col-md-3 col-lg-3">
      <?php dynamic_sidebar( 'gamestore-info' ); ?>
    </div>
    <div class="gamestore-navigation-widget-area col-sm-12 col-md-6 col-lg-6">
      <?php dynamic_sidebar( 'gamestore-navigation' ); ?>
    </div>
    <div class="contact-social-widget-area col-sm-12 col-md-3 col-lg-3">
      <?php dynamic_sidebar( 'contact-social-media' ); ?>
    </div>
</section>

  <section class="bottom-footer">
    <p><small>ⓒ Shanaya Bonagua | 2024</small></p>
  </section>
</footer>

<?php wp_footer(); ?>

</body>
</html>