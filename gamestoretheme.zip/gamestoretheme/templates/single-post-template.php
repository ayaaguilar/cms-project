<?php
/**
 * Template Name: Single Post Template
 * Template Post Type: post
 */
get_header();
$backgroundImg = wp_get_attachment_image_src(get_post_thumbnail_id($post->ID), 'full');
?>
<section class="post-masthead" style="background: url('<?php echo $backgroundImg[0]; ?>');">
  <div>
    <h1><?php the_title(); ?></h1>
  </div>
</section>
<section>
  <div class="single-post">
  <h1><?php the_title(); ?></h1>
    <?php echo get_the_content(); ?>
    <p>By: <?php the_author(); ?></p>
    <p>Date: <?php echo get_the_date(); ?></p>
    <p><?php the_tags(); ?></p>
    <p><?php echo the_category(',', '', get_the_ID()) ?></p>
  </div>
</section>
<?php get_footer(); ?>
