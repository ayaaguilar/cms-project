<?php
/**
 * Template Name: Homepage
 * Template Post Type: page
 */
get_header();
?>
  <main>
    <section class="masthead" style="background-image: url('<?php echo wp_kses_post(get_field('masthead_image')); ?>')">
      <div>
        <h1><?php echo wp_kses_post(get_field('main-heading')); ?></h1>
        <h2><?php echo wp_kses_post(get_field('sub-heading')); ?></h2>
      </div>
    </section>
    <section class="home-row-one row">
      <div class="col-sm-12 col-md-12 col-lg-12">
        <h3><?php echo wp_kses_post(get_field('row_one_title')); ?></h3>
        <p><?php echo wp_kses_post(get_field('row_one_text')); ?></p>
      </div>
    </section>
    <section class="home-row-two row">
      <div class="col-sm-12 col-md-8 col-lg-6">
        <h3><?php echo wp_kses_post(get_field('row_two_title')); ?></h3>
        <p><?php echo wp_kses_post(get_field('row_two_text')); ?></p>
      </div>
      <div class="col-sm-12 col-md-4 col-lg-6">
        <img src="<?php echo wp_kses_post(get_field('row_two_image')); ?>" alt="<?php echo wp_kses_post(get_field('row_two_image_alt_text')); ?>">
      </div>
    </section>

    <!-- featured products -->
    <section class="featured-products">
  <div>
    <h3>Featured Products</h3>
    <?php
    $args = array(
      'post_type' => 'product',
      'posts_per_page' => 3,
      'tax_query' => array(
        array(
          'taxonomy' => 'product_visibility',
          'field'    => 'name',
          'terms'    => 'featured',
          'operator' => 'IN',
        ),
      ),
    );
    $featured_query = new WP_Query($args);
    if ($featured_query->have_posts()) : 
      while ($featured_query->have_posts()) : $featured_query->the_post();
        wc_get_template_part('content', 'product');
      endwhile;
    else :
      echo '<p>No featured products found</p>';
    endif;
    wp_reset_postdata();
    ?>
  </div>
</section>


  </main>
<?php
get_footer();
